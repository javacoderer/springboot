package net.se.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
