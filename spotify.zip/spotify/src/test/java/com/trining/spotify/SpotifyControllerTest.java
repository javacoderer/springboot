package com.trining.spotify;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import controller.SpotifyController;

@ExtendWith(MockitoExtension.class)
public class SpotifyControllerTest {

    @Mock
    private SpotifyService spotifyService; // Mock the service class if fetchSpotifyData is in it

    @InjectMocks
    private SpotifyController spotifyController; // Controller to be tested

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(spotifyController).build();
    }

    @Test
    public void testGetTrack() throws Exception {
        String trackId = "123";
        String authorizationHeader = "Bearer some-token";
        String expectedResponse = "{\"trackName\":\"Sample Track\"}"; // Adjust based on expected JSON response

        // Mock the fetchSpotifyData method if it's in the SpotifyService class
        when(spotifyService.fetchSpotifyData(anyString(), anyString()))
            .thenReturn(ResponseEntity.ok(expectedResponse));

        // Perform the GET request and verify the results
        mockMvc.perform(get("/tracks/{trackId}", trackId)
                .header("Authorization", authorizationHeader))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedResponse));

        // Verify that fetchSpotifyData was called with the correct parameters
        verify(spotifyService, times(1)).fetchSpotifyData(anyString(), anyString());
    }
}

