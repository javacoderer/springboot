package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/spotify")
public class SpotifyController {
	private final RestTemplate restTemplate;

	@Autowired
	public SpotifyController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	// Base URL for Spotify API
	private static final String SPOTIFY_API_BASE_URL = "https://api.spotify.com/v1";

	// Endpoint to get a user's profile information
	@GetMapping("/me")
	public ResponseEntity<String> getCurrentUserProfile(@RequestHeader("Authorization") String authorizationHeader) {
		String url = SPOTIFY_API_BASE_URL + "/me";
		return fetchSpotifyData(url, authorizationHeader);
	}

	// Endpoint to get a user's playlists
	@GetMapping("/me/playlists")
	public ResponseEntity<String> getUserPlaylists(@RequestHeader("Authorization") String authorizationHeader) {
		String url = SPOTIFY_API_BASE_URL + "/me/playlists";
		return fetchSpotifyData(url, authorizationHeader);
	}

	// Endpoint to get an album by its ID
	@GetMapping("/albums/{albumId}")
	public ResponseEntity<String> getAlbum(@PathVariable String albumId,
			@RequestHeader("Authorization") String authorizationHeader) {
		String url = SPOTIFY_API_BASE_URL + "/albums/" + albumId;
		return fetchSpotifyData(url, authorizationHeader);
	}

	// Endpoint to get a track by its ID
	@GetMapping("/tracks/{trackId}")
	public ResponseEntity<String> getTrack(@PathVariable String trackId,
			@RequestHeader("Authorization") String authorizationHeader) {
		String url = SPOTIFY_API_BASE_URL + "/tracks/" + trackId;
		return fetchSpotifyData(url, authorizationHeader);
	}

	// Generic method to fetch data from the Spotify API
	private ResponseEntity<String> fetchSpotifyData(String url, String authorizationHeader) {
		// Set the Authorization header with the access token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", authorizationHeader);
		// Create the HTTP request entity
		HttpEntity<String> entity = new HttpEntity<>(headers);
		// Make the request and return the response
		return restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
	}
}
