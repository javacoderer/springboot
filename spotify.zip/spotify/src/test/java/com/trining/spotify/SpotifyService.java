package com.trining.spotify;

public class SpotifyService {

	public Object fetchSpotifyData(String url, String autherizationHeader) {
		return null;
	}

}
